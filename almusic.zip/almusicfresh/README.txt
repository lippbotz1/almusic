ALMUSIC ANDROID - GITHUB ACTIONS PROJECT

This is the Android source project from almusic_android_starter_v1.zip, with the project folder flattened so the Gradle files are at repository root and a GitHub Actions workflow added.

To build using GitHub:
1. Upload the CONTENTS of this ZIP to the root of your repository (not the ZIP file itself).
2. Commit to branch main or master.
3. Open Actions and select Build Almusic APK.
4. Download Almusic-debug-APK from the successful run's Artifacts section.

This starter opens https://sjsjsj-blush.vercel.app/ in a WebView. It does not yet implement native background media session controls.
